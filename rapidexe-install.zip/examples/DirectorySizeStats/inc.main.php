<?php

function getFolderSize($start) {

    exec("dir \"$start\" /s",$a);
    $a = array_slice($a,-2,1);
    $size = array_shift($a);
    $size = explode(")",$size)[1];
    $size = preg_replace("/[^0-9]/","",$size);
    return intval($size);

}


function showChart($folderSizes) {
    $a = $folderSizes;
    $m = 0;foreach($a as $dir=>$sum) $m = max($m,$sum); if(!$m) return;
    $r = 20/$m;
    print "       Total size   Folder                           Chart\n";
    print "-------------------------------------------------------------------------------\n";
    foreach($a as $dir=>$sum) {
        $name = basename($dir);
        $bar = str_repeat("#",ceil($sum*$r));
        printf("  %15s | %-30s | %s\n",number_format($sum),substr($name,0,30),$bar);
    }
}


