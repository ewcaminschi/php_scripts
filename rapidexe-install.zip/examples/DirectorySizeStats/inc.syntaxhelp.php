<?php

function syntaxHelp() {

    return "\n".ltrim(strtr("

dirstats                                             (a PHPFlexer example tool)
-------------------------------------------------------------------------------

    Displays a summary of subfolder sizes, with a chart display on the right.
    Well, not much of a chart display but it will show you the heaviest guys.


    Syntax:

        dirstats <path>

    Example:

        dirstats d:/dev/steve/public_html

",["\t"=>"    "]));

}



#;
