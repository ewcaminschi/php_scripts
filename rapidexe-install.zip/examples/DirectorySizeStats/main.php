<?php
include("inc.helpers.php");
include("inc.syntaxhelp.php");
include("inc.main.php");


$a = $argv;
$myself = array_shift($a); // $a[0] is always the script/exe name
$path   = array_shift($a); if($path==="?") die(syntaxHelp());
$path   = $path?:".";
$path	= realpath($path);
$sizes  = [];

foreach(glob("$path/*",GLOB_ONLYDIR) as $dir) {
	$dir = winSlashes($dir);
	$name = basename($dir);
	printf("\rScanning %-50s",substr($name,0,47)."...");
	$sizes[$dir] = getFolderSize($dir);
}

if(!count($sizes)) die("No children of this folder ($path)\n");

printf("\r%-60s\n\n","Children of $path:");
showChart($sizes);


