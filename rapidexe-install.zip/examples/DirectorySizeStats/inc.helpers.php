<?php

function winSlashes($s) {
    return strtr($s,'/','\\');
}
