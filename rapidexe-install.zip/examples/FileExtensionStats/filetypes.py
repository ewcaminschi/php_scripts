
import os
import sys

a = sys.argv[1:]
dir = a[0] if len(a)>0 else "."
dir = os.path.realpath(dir)

exts = {}

files = os.listdir(dir)
for file in files:
    file = os.path.realpath(dir+'/'+file)
    if os.path.isdir(file): continue
    (xx,ext) = os.path.splitext(file)
    if ext not in exts: exts[ext]=0
    exts[ext]+=1

print("Checking out",dir)
print("------------------------------------------------------------")

for ext,ctr in exts.items():
    s = "s" if ctr>1 else " "
    if ext>'':
        print(" %5d file%s with extension '%s'" % (ctr,s,ext))
    else:
        print(" %5d file%s with no extension" % (ctr,s))


